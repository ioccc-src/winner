char*s="CODE",*p,b,d[9338],*q,x,*r=d;
int main(){
    ;for(p=q=5000+0+d;*s;s++)if(*s>32)*p++=*s-89?*s:32;
    for(p=INDX+q;(b=*p++);){
	for(d[17]=10;x=*p++,b<92&&34<b--;*r++=x)if(x==9*9)
		for(;*q;x=34)*r++=*q++;
	for(p-=b<92;b-->4*23;r++)*r=r[36-x];
    }
    puts(d);
    return(0);
}/*IOCCC2014IOCCC2014IOCCC2014IOCCC2014IOCCC*/
