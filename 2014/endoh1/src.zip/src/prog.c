







                #include<stdio.h>/*IOCCC2014            2014    2014    IOCCC2014IOCCC2014IOCCC201*/
                char*s="\"nsu{AntynCnuq}Bnu{            sEot    ln>b    )+c^g+@`+]_osk{;j@bkg&c<'^o\
                r'Q]                    bh'l    vQ^k                    g&c:                    %n|\
                N]_o                    ptj9    lwg+                    )d:b                    kg$\
                c8#^    #g+)d8`a%g+)    d8`_                g&;bh'oq    Q^)g    +&kcNlyMc+)d    8`a\
                `g+@    u)|d8ak=bl}(    Q^og                (O{MK6lM    L(rR    pOpM866OsRlm    N(q\
                Q]##    OsR#M_(lQoOa    N9$m    vOwwRor~        }(cN    mkM:    q(Q]%_(uU]}_    {8b\
                %mRh    #S^`#mOaaD%/    RI4$    4SNH$%N4        RlMG    /2MJ    24O3NF(tQ?1l    N*N\
                +Q]l    mq9l8b$^#h$#    .d,d    xv#mSOPm    R8`/        lM;b    h&^/lM:k8b%&    Q^-\
                h%c9    .#,/&N$McPc%    -d8,    $c8``7:b    %^h%        :79b    $^%$7ON8r%Qr    h$Q\
                On%q                    N%O~        M$qN$OMp    RmPQ    O%rQ                    $rQ\
                MkQN                    77O#        dj#Nkd$7    O%d8    ``(r                    RmM\
                :(luN](%mRMmO%lNRmO_loa8%%O<    b(lQ    h'lQ    O^ln    ;b'%N&O^6sN#M9slltwzh&TmS$'\
                %R#ON$oNS&pRM7O$'%S#ON$oNS&p    SMd9    ``(t    pkO9    $:nk8b#^%}kx#O%lMtpk#OQOP:#\
                                                mR8`}(qQ        O<b\
                                                '7M{N^kh        'Q]\
                    7sN'    M8q;k'N_7vN'nSM8    'nR;    $%M'    TamS&7O#d#7O    &d8`z9b$    ^h$\
                    rQ]6    yN$_$$pQaM8m{px$    TmSt    6O#N    sM$nRmUd#7Os    d77sNOsd    8`j\
                =nk;        |8k9    b1g(    Q^)$c:%]    k*Q]g$9%_h*]+wnS        _+sTaa:&%{R\
                M<%{        S{O_    &<#w    kP8#a;'(    0d:`184>b)^15)OM        :23h)QN<'/M\
                    =b(^'h(Q]0h#    c_kah%0d9`b'/O(Q^(/SlM90%M(/            RM;&    $c&kckQ,    -$c\
                    .&kccMcOP$&d    9g(=``6:69j=b5g(Q^3(2lNUO<b4            'Q^s    ;b&^%%pQ    M8k\
                        $7O#cQ]0(2(Q]'2O    3'Q]'_3a    N_1'    5OMaMch&T$mR#nRMPmSk    U$7\
                        O#d8_a%%mS]l_%mR    mS]$]h$9    j_la    _$6N]g$9j_laaaN:`g'<    ``7\
                oM:6%N9b%g$Q        ^6%N8b%g    #Q^l            peoqemtemw#jQ7#QO$jQ    O7$Q    Ok#\
                $7OMQ]k_#$7O        ckQaOrON    epne            luelue`lpeoqempepneu    e`kf    _a`\
                                                lf))    *+,**,*)-)/),0).0(6/2+667,(&    $##\
                                                #;=@    D*0;#include<stdio.h>@intYH[    9`%\
                .],*s,*c,d,t;`;'main(`-9n,ch            ar*v    []){        for(s=c=    H+3`XI;\
                (*++s=Q[d++]););for(;n>1&&(*            ++s=    v[1]        [tgANs=H    ;d=*c++\
                %93,                    d-9;    ){in    tYv=*s,g        []={    n+v,        v-n,n*_\
                ,#^_                    ,,<v    ,n?v    /n:0`,#%        `,,v    >>n,        v==n}ay\
                >t=0    ;d<4&&d>=2*!    !n&&    (c-=d/3*2_KK3+*c++,t||v!=98+d);)        t+=v++/6-16\
                ?0:v    /2%3-1cq*d-1    4;t>    0_t$<3_z(105<*c_X'=t*21aq@-106;n        =d>76?s--,g\
                [d-7    7]:d>55?H_1)    21]=    n,*_@_8(        9?*++s_4&12>d_C`f3]+=21-d*2\
                :d<3    4?t:_Zadat57    <d?p    utchar(n        ),v:6<a](g+99]=a{d2#:`xa6,n\
                ;}re    turnY_.",*p,    b,d[        9338    ],*q,x,*r=d;            int main(){;for(
                p=q=    5000+0+d;*s;    s++)        if(*    s>32)*p++=*s            -89?*s:32;for(p=
                1152                    +q;(    b=*p++);){for(d[17]=            10;x    =*p++,b<
                92&&                    34<b    --;*r++=x)if(x==9*9)            for(    ;*q;x=34
                )*r++=*q++;for(p-=b<92;b-->4        *23;r++)    *r=r[36-    x];}puts    (d);
                return(0);}/*IOCCC2014IOCCC2        014IOCCC    2014IOCC    C2014IOC    CC*/








